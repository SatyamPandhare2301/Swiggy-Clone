const About = () => {
  return (
    <div className="about-container">
      <h1>Welcome to QuickEats</h1>
      <p>
        At <strong>QuickEats</strong>, we're redefining the way you discover and enjoy food. 
        Whether you're craving local delicacies or your favorite fast food, 
        we connect you with the best restaurants around — fast, easy, and reliable.
      </p>

      <h2>Our Mission</h2>
      <p>
        To make food discovery simple and joyful by providing quick access 
        to menus, reviews, and delivery from your favorite restaurants.
      </p>

      <h2>Why QuickEats?</h2>
      <ul>
        <li>🚀 Lightning-fast browsing and ordering</li>
        <li>📍 Location-based recommendations</li>
        <li>🍽️ Menus from top-rated restaurants</li>
        <li>⭐ Customer ratings and real reviews</li>
        <li>🔒 Secure and seamless transactions</li>
      </ul>

      <h2>How It Works</h2>
      <ol>
        <li>Search or browse your favorite cuisine.</li>
        <li>Explore restaurant menus and ratings.</li>
        <li>Select a restaurant to view the full menu.</li>
        <li>Enjoy quick delivery or dine-in options!</li>
      </ol>

      <p>
        Join thousands of food lovers who trust <strong>QuickEats</strong> to 
        find and order their next great meal!
      </p>
    </div>
  );
};

export default About;
