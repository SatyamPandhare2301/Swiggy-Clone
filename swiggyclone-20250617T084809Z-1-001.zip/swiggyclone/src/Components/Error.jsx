const Error = () => {
  return (
    <div>
        <h2>Oops..Something Went Wrong</h2>
        <img src='https://img.freepik.com/premium-vector/internet-connection-problem-concept-illu   stration-404-found-error-page-isolated-white-background-funny-gray-cat-isolated-vector-illustrations_450656-204.jpg?size=626&ext=jpg&ga=GA1.1.1412446893.1704758400&semt=ais'
        
        alt='Error Cat'
        />
    </div>
  );
};

export default Error;