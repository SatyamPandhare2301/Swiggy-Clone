const Shimmer = () => {
    const shimmerCardCount = 12;

    const shimmerCards = Array.from({ length: shimmerCardCount }, (_, index) => (
        <div key={index} className="shimmer-card">
            <div className="shimmer-content"></div>
        </div>
    ));

    return <div className="shimmer-container">{shimmerCards}</div>;
};

export default Shimmer;
