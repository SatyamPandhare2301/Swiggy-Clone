import { useState, useEffect } from "react";
import Shimmer from "./Shimmer";

const RestaurantMenu = () => {
  const [resinfo, setResinfo] = useState(null);
  //let name;

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    const data = await fetch(
      "https://www.swiggy.com/dapi/restaurants/list/v5?lat=18.533472&lng=73.834371&is-seo-homepage-enabled=true&page_type=DESKTOP_WEB_LISTING"
    );

    const json = await data.json();
    console.log(json);
    setResinfo(json.data);
  };

  if (resinfo === null) return <Shimmer />;

  const restaurant =
  resinfo?.data?.cards?.[4]?.card?.card?.gridElements?.infoWithStyle?.restaurants?.[0]?.info;

return (
  <div className="menu">
    {restaurant ? (
      <>
        <h1>{restaurant.name}</h1>
        <h2>{restaurant.cuisines?.join(", ")}</h2>
      </>
    ) : (
      <p>Restaurant info not available</p>
    )}
  </div>
);
}

export default RestaurantMenu;
