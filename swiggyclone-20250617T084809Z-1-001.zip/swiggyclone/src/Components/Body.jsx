import RestaurantCard from "./RestaurantCard";
import { useEffect, useState } from "react";
import Shimmer from "./Shimmer";


const Body = () => {
    // const [originalList, setOriginalList] = useState([]);
    const [listofrestaurants, setListofRestaurants] = useState([]);
    const[searchText,setsearchText] = useState("")

  useEffect(() => {
    fetchData(); 
  }, []);

  const fetchData = async () => {
    const data = await fetch(
      "https://www.swiggy.com/dapi/restaurants/list/v5?lat=18.533472&lng=73.834371&is-seo-homepage-enabled=true&page_type=DESKTOP_WEB_LISTING"
    );

    const json = await data.json();

    setListofRestaurants(
      json?.data?.cards[4]?.card?.card?.gridElements?.infoWithStyle?.restaurants
    );
  }; 

  return listofrestaurants.length == 0 ? <Shimmer /> : (
    <div className="search-container">
      <div className="search-bar">
      <input
        type="text"
        className="search" 
        placeholder="Search for restaurants"
        value={searchText}
        onChange={(e)=>{
          setsearchText(e.target.value)
        }}
      />
      <button onClick={()=>{

        const filteredRestaurant = listofrestaurants.filter((res) => res.info.name.includes(searchText));  
      
        setListofRestaurants(filteredRestaurant);


      }}>Search</button>

      <button
        className="filter-btn"
        onClick={() => {
          const filteredlist = listofrestaurants.filter(
            (res) => res.info.avgRating > 4.2,
            console.log("Updated")
          );
          console.log(filteredlist);
          setListofRestaurants(filteredlist);
        }}
      >
        Top Rated Restaurants
      </button>
      </div>

      <div className="restro-container">
        {/* <RestaurantCard resData = {resList[1]} />
          <RestaurantCard resData = {resList[2]} />
          <RestaurantCard resData = {resList[3]} />
          <RestaurantCard resData = {resList[4]} />
          <RestaurantCard resData = {resList[5]} />
          <RestaurantCard resData = {resList[6]} />
          <RestaurantCard resData = {resList[7]} />
          <RestaurantCard resData = {resList[8]} />
          <RestaurantCard resData = {resList[9]} />
          <RestaurantCard resData = {resList[10]} />
          <RestaurantCard resData = {resList[11]} />
          <RestaurantCard resData = {resList[12]} />
          <RestaurantCard resData = {resList[13]} />
          <RestaurantCard resData = {resList[14]} />
          <RestaurantCard resData = {resList[15]} />
          <RestaurantCard resData = {resList[16]} /> */}
        {/* OR */}
        {listofrestaurants.map((restaurant) => (
          <RestaurantCard key={restaurant.info.id} resData={restaurant} />
        ))}

        {/* Unique Key>>>>>>>>>>>>>>>>>>>>>> >>>>>>>>>>>>Best Practice */}
      </div>
      </div>
    
    
  );
};

export default Body;
