import { useEffect } from "react";
import Logo from "./logo.png"
import { Link } from "react-router-dom";

const Header = () => {

    //if no dependency array is used in useState, then useeffect is called after every render.
    //if dependency array is empty = [] => Useeffect is called after the initianl render (just once)
    //if we write component name in dependancy array = [btnReact] => Useeffect is called everytime the btnReact will be updated
    useEffect(()=>{
      console.log("Good Morning")
    },[])


    return (
      <div className="Header">
        <div className="logo-container">
          {/* Provide the correct path to your Logo.png file */}
          <img className="logo" src={Logo} alt="Logo" />
        </div>
        <div className="nav-items">
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to ="#">Offers</Link>
            </li>
            <li>
              <Link to="about">About Us</Link>
            </li>
            <li>
              <Link to="contact">Contact Us</Link>
            </li>
            <li>
              <Link to="#">Gallery</Link>
            </li>
          </ul>
        </div>
      </div>
    );
  };

  export default Header;